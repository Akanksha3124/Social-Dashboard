# Social Media Engagement Dashboard

Track and analyze YouTube and Instagram engagement metrics with charts,
heatmaps, and a final interactive HTML dashboard.

---

## Project Structure

```
social_dashboard/
├── .env                          ← Your API keys (never share this)
├── .gitignore
├── requirements.txt
├── data/
│   ├── raw/                      ← Raw API data (auto-created)
│   ├── processed/                ← Chart images (auto-created)
│   └── cleaned/                  ← Cleaned CSVs + SQLite DB
├── scripts/
│   ├── collect_youtube.py        ← Step 1a: Pull YouTube data
│   ├── collect_instagram.py      ← Step 1b: Pull Instagram data
│   └── clean_data.py             ← Step 2:  Clean & save to DB
├── notebooks/
│   ├── 01_eda.ipynb              ← Step 3: EDA charts in Jupyter
│   └── 02_analyze.ipynb          ← Step 4: Deep analysis in Jupyter
└── dashboard/
    ├── generate_dashboard.py     ← Step 5: Build HTML dashboard
    └── dashboard.html            ← Final output (open in browser)
```

---

## Setup (do this once)

### 1. Install Python libraries
```bash
pip install -r requirements.txt
```

### 2. Fill in your API keys
Open `.env` and replace the placeholder values:
```
YOUTUBE_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXXXXX
INSTAGRAM_ACCESS_TOKEN=EAAxxxxxxxxxxxxxxxxxxxxxxx
INSTAGRAM_USER_ID=17841XXXXXXXXXX
```
See HOW_TO_GET_KEYS.md if you need help getting these.

---

## Running the Project (step by step)

### Step 1 — Collect data (run in Terminal / VS Code)

**YouTube:**
```bash
# First open scripts/collect_youtube.py and set your CHANNEL_ID
python scripts/collect_youtube.py
```
Output: `data/raw/youtube_data.csv`

**Instagram:**
```bash
python scripts/collect_instagram.py
```
Output: `data/raw/instagram_data.csv`

---

### Step 2 — Clean data (run in Terminal)
```bash
python scripts/clean_data.py
```
Output: `data/cleaned/youtube_clean.csv`, `data/cleaned/instagram_clean.csv`, `data/engagement.db`

---

### Step 3 — EDA (run in Jupyter)
```bash
jupyter notebook
```
Then open `notebooks/01_eda.ipynb` and run all cells (Cell → Run All).

Output: Charts saved to `data/processed/`, strategy summary printed.

---

### Step 4 — Deep analysis (run in Jupyter)
Still in Jupyter, open `notebooks/02_analyze.ipynb` and run all cells.

Output: Content score table, monthly trends, correlation matrix.

---

### Step 5 — Generate dashboard (run in Terminal)
```bash
python dashboard/generate_dashboard.py
```
Output: `dashboard/dashboard.html`

---

### Step 6 — View your dashboard
Just open `dashboard/dashboard.html` in Chrome or Firefox.
Double-click the file, or run:
```bash
# Mac
open dashboard/dashboard.html

# Windows
start dashboard/dashboard.html

# Linux
xdg-open dashboard/dashboard.html
```

---

## Automate daily data collection (optional)

Add this to your cron (Linux/Mac):
```bash
crontab -e
```
Add this line to run every day at 8am:
```
0 8 * * * cd /path/to/social_dashboard && python scripts/collect_youtube.py && python scripts/collect_instagram.py && python scripts/clean_data.py && python dashboard/generate_dashboard.py
```

---

## Notes

- YouTube API: free 10,000 units/day quota — more than enough
- Instagram API: requires Business or Creator account linked to a Facebook Page
- The dashboard works even with only YouTube OR only Instagram data
